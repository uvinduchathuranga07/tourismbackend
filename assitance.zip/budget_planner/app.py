from flask import Flask, Blueprint, request, jsonify
from pathlib import Path
import pandas as pd
import joblib
import random


BASE_DIR = Path(__file__).resolve().parent


# load model and encoders
budget_model = joblib.load(BASE_DIR / "xgb_budget_model.pkl")

le_interest = joblib.load(BASE_DIR / "le_interest.pkl")
le_travel = joblib.load(BASE_DIR / "le_travel.pkl")
le_transport = joblib.load(BASE_DIR / "le_transport.pkl")
le_budget = joblib.load(BASE_DIR / "le_budget.pkl")
le_route = joblib.load(BASE_DIR / "le_route.pkl")


hotels_df = pd.read_csv(BASE_DIR / "hotels_300.csv")

bp = Blueprint("budget_planner", __name__)

# route generator moved to configurations.py
try:
    from .configurations import generate_route
except ImportError:  # running as a script
    from configurations import generate_route

# ==========================================
# HOTEL RECOMMENDATION
# ==========================================

def get_hotels(route):

    places = [

        p.strip()

        for p in route.split("->")

        if p.strip() != "Colombo"
    ]

    hotels = []

    for place in places:

        result = hotels_df[
            hotels_df["place"] == place
        ]

        if not result.empty:

            hotel = result.sample(1).iloc[0]

            hotels.append({

                "place": place,

                "hotel_name": hotel["hotel_name"],

                "price_lkr": int(hotel["avg_price_lkr"])
            })

    return hotels

# ==========================================
# HOME
# ==========================================

@bp.route("/")
def home():

    return jsonify({

        "message": "Sri Lanka AI Tourism Planner Running"

    })

# ==========================================
# PREDICT API
# ==========================================

@bp.route("/predict", methods=["POST"])
def predict():

    try:

        # ==========================================
        # GET INPUT
        # ==========================================

        data = request.get_json()

        budget = int(data["budget"])

        days = int(data["days"])

        interest = data["interest"]

        travel_type = data["travel_type"]

        transport_mode = data["transport_mode"]

        # ==========================================
        # GENERATE ROUTE
        # ==========================================

        predicted_route = generate_route(

            interest,
            days,
            budget
        )

        # ==========================================
        # CREATE BUDGET LEVEL
        # ==========================================

        if budget < 60000:

            budget_level = "low"

        elif budget < 150000:

            budget_level = "medium"

        else:

            budget_level = "high"

        # ==========================================
        # ENCODE FEATURES
        # ==========================================

        interest_encoded = le_interest.transform(
            [interest]
        )[0]

        travel_encoded = le_travel.transform(
            [travel_type]
        )[0]

        transport_encoded = le_transport.transform(
            [transport_mode]
        )[0]

        budget_encoded = le_budget.transform(
            [budget_level]
        )[0]

        # ==========================================
        # IMPORTANT
        # USE EXISTING TRAINED ROUTE
        # ==========================================

        safe_route = "Colombo -> Kandy -> Nuwara Eliya -> Ella -> Colombo"

        route_encoded = le_route.transform(
            [safe_route]
        )[0]

        # ==========================================
        # CREATE MODEL INPUT
        # ==========================================

        budget_input = pd.DataFrame([[
            days,
            budget_encoded,
            interest_encoded,
            travel_encoded,
            transport_encoded,
            route_encoded
        ]], columns=[

            "days",
            "budget_level",
            "interest",
            "travel_type",
            "transport_mode",
            "recommended_route"
        ])

        # ==========================================
        # PREDICT BUDGET
        # ==========================================

        predicted_budget = budget_model.predict(
            budget_input
        )[0]

        predicted_budget = round(
            float(predicted_budget),
            2
        )

        # ==========================================
        # COST BREAKDOWN
        # ==========================================

        hotel_cost = round(
            predicted_budget * 0.45,
            2
        )

        fuel_cost = round(
            predicted_budget * 0.20,
            2
        )

        food_cost = round(
            predicted_budget * 0.15,
            2
        )

        attraction_cost = round(
            predicted_budget * 0.20,
            2
        )

        daily_budget = round(
            predicted_budget / days,
            2
        )

        # ==========================================
        # GET HOTELS
        # ==========================================

        recommended_hotels = get_hotels(
            predicted_route
        )

        # ==========================================
        # FINAL RESPONSE
        # ==========================================

        response = {

            "success": True,

            "input": {

                "budget": budget,

                "days": days,

                "interest": interest,

                "travel_type": travel_type,

                "transport_mode": transport_mode
            },

            "prediction": {

                "predicted_route": predicted_route,

                "estimated_total_budget_lkr": predicted_budget,

                "estimated_daily_budget_lkr": daily_budget,

                "estimated_hotel_cost_lkr": hotel_cost,

                "estimated_fuel_cost_lkr": fuel_cost,

                "estimated_food_cost_lkr": food_cost,

                "estimated_attraction_cost_lkr": attraction_cost,

                "recommended_hotels": recommended_hotels
            }
        }

        return jsonify(response)

    except Exception as e:

        return jsonify({

            "success": False,

            "error": str(e)
        })

# ==========================================
# RUN APP
# ==========================================

if __name__ == "__main__":

    app = Flask(__name__)
    app.register_blueprint(bp)
    app.run(
        host="0.0.0.0",
        port=5000,
        debug=True
    )