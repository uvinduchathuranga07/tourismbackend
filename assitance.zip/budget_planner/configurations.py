import random


def generate_route(interest, days, budget):

    if interest == "beach":

        if days >= 5:

            routes = [

                "Colombo -> Bentota -> Galle -> Mirissa -> Colombo",

                "Colombo -> Trincomalee -> Arugam Bay -> Colombo"
            ]

        else:

            routes = [

                "Colombo -> Galle -> Colombo"
            ]

    elif interest == "nature":

        routes = [

            "Colombo -> Kandy -> Ella -> Colombo",

            "Colombo -> Kandy -> Nuwara Eliya -> Ella -> Colombo"
        ]

    elif interest == "cultural":

        routes = [

            "Colombo -> Sigiriya -> Polonnaruwa -> Colombo"
        ]

    elif interest == "wildlife":

        routes = [

            "Colombo -> Yala -> Udawalawe -> Colombo"
        ]

    elif interest == "adventure":

        routes = [

            "Colombo -> Kitulgala -> Ella -> Colombo"
        ]

    else:

        routes = [

            "Colombo -> Kandy -> Galle -> Colombo"
        ]

    return random.choice(routes)
