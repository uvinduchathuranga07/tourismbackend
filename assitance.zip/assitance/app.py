from flask import Flask, Blueprint, request, jsonify
from pathlib import Path
import pandas as pd
import joblib
import requests

bp = Blueprint("assistance", __name__)

BASE_DIR = Path(__file__).resolve().parent

DESTINATIONS = [
    "Ella",
    "Galle",
    "Sigiriya",
    "Kandy",
    "Nuwara Eliya",
    "Mirissa",
    "Bentota",
    "Arugam Bay",
    "Anuradhapura",
    "Polonnaruwa",
    "Jaffna",
    "Trincomalee",
    "Yala",
    "Hikkaduwa",
    "Dambulla"
]

# Approximate city coordinates for live weather lookup
DESTINATION_COORDINATES = {
    "Ella": (6.8667, 81.0466),
    "Galle": (6.0535, 80.2210),
    "Sigiriya": (7.9570, 80.7603),
    "Kandy": (7.2906, 80.6337),
    "Nuwara Eliya": (6.9497, 80.7891),
    "Mirissa": (5.9483, 80.4716),
    "Bentota": (6.4218, 79.9950),
    "Arugam Bay": (6.8404, 81.8378),
    "Anuradhapura": (8.3114, 80.4037),
    "Polonnaruwa": (7.9403, 81.0188),
    "Jaffna": (9.6615, 80.0255),
    "Trincomalee": (8.5874, 81.2152),
    "Yala": (6.3725, 81.5185),
    "Hikkaduwa": (6.1407, 80.1010),
    "Dambulla": (7.8742, 80.6511)
}

OPEN_METEO_FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

# ----------------------------
# Load models
# ----------------------------
rf_crowd = joblib.load(BASE_DIR / "crowd.pkl")
rf_weather = joblib.load(BASE_DIR / "random_forest_weather_model.pkl")

crowd_columns = joblib.load(BASE_DIR / "crowd_columns.pkl")
weather_columns = joblib.load(BASE_DIR / "weather_columns.pkl")

# ----------------------------
# Simple NLP
# ----------------------------
def parse_user(text):
    text = text.lower()
    return {
        "prefer_low_crowd": "low crowd" in text or "less crowd" in text
    }


def get_live_weather_features(location):
    coords = DESTINATION_COORDINATES.get(location)
    if not coords:
        return {}

    lat, lon = coords
    params = {
        "latitude": lat,
        "longitude": lon,
        "current": "temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation",
        "daily": "uv_index_max",
        "timezone": "auto",
        "forecast_days": 1
    }

    try:
        response = requests.get(OPEN_METEO_FORECAST_URL, params=params, timeout=8)
        response.raise_for_status()

        payload = response.json()
        current = payload.get("current", {})
        daily = payload.get("daily", {})

        time_value = current.get("time")
        if time_value:
            dt = pd.to_datetime(time_value)
        else:
            dt = pd.Timestamp.now()

        uv_values = daily.get("uv_index_max", [6])
        uv_index = float(uv_values[0]) if uv_values else 6.0

        return {
            "month": int(dt.month),
            "day_of_week": int(dt.dayofweek),
            "is_weekend": int(dt.dayofweek >= 5),
            "rainfall_mm": float(current.get("precipitation", 5)),
            "temperature_c": float(current.get("temperature_2m", 28)),
            "humidity": float(current.get("relative_humidity_2m", 75)),
            "wind_speed": float(current.get("wind_speed_10m", 10)),
            "uv_index": uv_index
        }
    except (requests.RequestException, ValueError, TypeError, IndexError):
        return {}

# ----------------------------
# Predict Crowd (FIXED)
# ----------------------------
def predict_crowd(location, crowd_input):

    sample = crowd_input.copy()

    # defaults
    sample.setdefault("month", 7)
    sample.setdefault("day_of_week", 2)
    sample.setdefault("is_weekend", 0)
    sample.setdefault("lag_1", 100)
    sample.setdefault("lag_2", 100)
    sample.setdefault("lag_3", 100)

    # 🔥 LOCATION VARIATION (IMPORTANT FIX)
    location_factor = {
        "Ella": -20,
        "Galle": 10,
        "Sigiriya": 30,
        "Kandy": 15
    }

    base = location_factor.get(location, 0)

    sample["lag_1"] += base
    sample["lag_2"] += base
    sample["lag_3"] += base

    # one-hot encoding
    for col in crowd_columns:
        if "location_" in col:
            sample[col] = 1 if col == f"location_{location}" else 0

    df = pd.DataFrame([sample])
    df = df.reindex(columns=crowd_columns, fill_value=0)

    return float(rf_crowd.predict(df)[0])

# ----------------------------
# Predict Weather (FIXED)
# ----------------------------
def predict_weather(location, weather_input):

    sample = weather_input.copy()

    # defaults
    sample.setdefault("month", 7)
    sample.setdefault("day_of_week", 2)
    sample.setdefault("is_weekend", 0)
    sample.setdefault("rainfall_mm", 5)
    sample.setdefault("temperature_c", 28)
    sample.setdefault("humidity", 75)
    sample.setdefault("wind_speed", 10)
    sample.setdefault("uv_index", 6)

    # 🔥 LOCATION VARIATION
    if location in ["Ella", "Kandy"]:
        sample["rainfall_mm"] += 3
    elif location in ["Sigiriya"]:
        sample["temperature_c"] += 2
    elif location in ["Galle"]:
        sample["humidity"] += 5

    # one-hot encoding
    for col in weather_columns:
        if "location_" in col:
            sample[col] = 1 if col == f"location_{location}" else 0
        if "weather_condition_" in col:
            sample[col] = 0

    # 🔥 DYNAMIC WEATHER CONDITION
    if sample["rainfall_mm"] > 8:
        sample["weather_condition_rainy"] = 1
    elif sample["rainfall_mm"] > 3:
        sample["weather_condition_cloudy"] = 1
    else:
        sample["weather_condition_sunny"] = 1

    df = pd.DataFrame([sample])
    df = df.reindex(columns=weather_columns, fill_value=0)

    pred = rf_weather.predict(df)[0]

    return {0: "Low", 1: "Moderate", 2: "High"}[pred]

# ----------------------------
# Scoring (IMPROVED)
# ----------------------------
def calculate_score(crowd, weather, user):

    score = 0

    # crowd scoring
    if crowd < 80:
        score += 40
    elif crowd < 120:
        score += 25
    elif crowd < 160:
        score += 10

    # weather scoring
    if weather == "Low":
        score += 40
    elif weather == "Moderate":
        score += 20

    return score

# ----------------------------
# API
# ----------------------------
@bp.route("/recommend", methods=["POST"])
def recommend():

    data = request.json

    user_text = data.get("user_text", "")
    weather_override = data.get("weather", {})
    crowd_input = data.get("crowd", {})

    if not isinstance(weather_override, dict):
        weather_override = {}
    if not isinstance(crowd_input, dict):
        crowd_input = {}

    user = parse_user(user_text)

    results = []

    for place in DESTINATIONS:

        live_weather = get_live_weather_features(place)
        weather_input = {**live_weather, **weather_override}

        crowd = predict_crowd(place, crowd_input)
        weather = predict_weather(place, weather_input)

        score = calculate_score(crowd, weather, user)

        results.append({
            "place": place,
            "crowd": round(crowd, 2),
            "weather": weather,
            "score": score
        })

    results = sorted(results, key=lambda x: x["score"], reverse=True)

    return jsonify({
        "recommendations": results
    })


@bp.route("/predict", methods=["POST"])
def predict():

    return recommend()

# ----------------------------
# Run
# ----------------------------
if __name__ == "__main__":
    app = Flask(__name__)
    app.register_blueprint(bp)
    app.run(debug=True)